
  <!-- ======= Footer ======= -->
  <footer id="footer">
   
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>FamilyDentalCare</span></strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- End Footer --><?php /**PATH C:\laragon\www\klinikfamdentalcare\resources\views/main/layout/footer.blade.php ENDPATH**/ ?>