<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <?php echo e(Session::get('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php elseif(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <?php echo e(Session::get('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?><?php /**PATH D:\Laragon\www\klinikfamdentalcare\resources\views/admin/layout/alert.blade.php ENDPATH**/ ?>