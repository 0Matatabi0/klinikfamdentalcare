

<?php $__env->startSection('content'); ?>


<!-- ======= Appointment Section ======= -->
<section id="appointment" class="appointment">
  <div class="container" data-aos="fade-up" style="margin-top: 25vh;">

    <div class="section-title">
      <h2>Make an Appointment</h2>
      <p>Isi data diri anda pada form dibawah berikut. Silahkan tunggu konfirmasi dari kami lewat Whatsapp.</p>
    </div>

    <form action="/appointment" method="POST" role="form" enctype="multipart/form-data" data-aos="fade-up" data-aos-delay="100" autocomplete="off">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-6 form-group mt-3 ">
          <label for="exampleFormControlInput1">  Nama</label>
          <input type="text" name="nama_pasien" class="form-control" value="<?php echo e(old('nama_pasien')); ?>" required>
          <?php $__errorArgs = ['nama_pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div id="defaultFormControlHelp" class="form-text bg-warning text-black">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6 form-group mt-3 ">
          <label for="exampleFormControlInput1">  Email</label>
          <input type="email" class="form-control" name="email_pasien" value="<?php echo e(old('email_pasien')); ?>" required>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 form-group mt-3 ">
          <label for="exampleFormControlInput1">  No Telepon</label>
          <input type="number" class="form-control" name="no_hp_pasien" value="62<?php echo e(old('no_hp_pasien')); ?>" required>
          <?php $__errorArgs = ['no_hp_pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div id="defaultFormControlHelp" class="form-text bg-warning text-black">
                <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6 form-group mt-3 ">
          <label for="exampleFormControlInput1">  Tanggal Janji</label>
          <input type="datetime-local" name="tanggal_janji" class="form-control datepicker" value="<?php echo e(old('tanggal_janji')); ?>" required>
          <?php $__errorArgs = ['tanggal_janji'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div id="defaultFormControlHelp" class="form-text bg-warning text-black">
                <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 form-group mt-3">
          <label for="exampleFormControlInput1">  Alamat</label>
          <textarea class="form-control" name="alamat_pasien" rows="5"  value="<?php echo e(old('alamat_pasien')); ?>" ></textarea>
            <?php $__errorArgs = ['alamat_pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div id="defaultFormControlHelp" class="form-text bg-warning text-black">
                  <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6 form-group mt-3">
          <label for="exampleFormControlInput1">  Keluhan</label>
          <textarea class="form-control" name="keluhan_pasien" rows="5" value="<?php echo e(old('keluhan_pasien')); ?>" ></textarea>
          <?php $__errorArgs = ['keluhan_pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div id="defaultFormControlHelp" class="form-text bg-warning text-black">
                <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-12">
          <div class="mb-3">
              <div class="text-start">
                  <button class="btn btn-primary btn-block" type="submit">
                      <span class="align-middle">Simpan</span>
                  </button>
              </div>
          </div>
      </div>
      </div>   
                  
      <!-- <div class="my-3">
        <div class="loading">Loading</div>
        <div class="error-message"></div>
        <div class="sent-message">Your appointment request has been sent successfully. Thank you!</div>
      </div> -->
     
      
    </div>
  </form>

  
</div>
</section><!-- End Appointment Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laragon\www\klinikfamdentalcare\resources\views/main/appointment.blade.php ENDPATH**/ ?>