
  <!-- ======= Footer ======= -->
  <footer id="footer">
   
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>FamilyDentalCare</span></strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- End Footer -->